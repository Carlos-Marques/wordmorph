#include "main.h"

int main(int argc, char *argv[]) {
  readfile(argv[1], argv[2]);

  return 0;
}
