#ifndef DIF_H
#define DIF_H

#include <stdio.h>
#include <stdlib.h>

int dif(char *a, char *b, int size);  /* calculates dif between 2 words of given size */

#endif
